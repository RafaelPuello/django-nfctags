from django.contrib import admin

from .models import NFCTag

admin.site.register(NFCTag)  # noqa
